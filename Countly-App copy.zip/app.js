const STORAGE_KEY = "countly-counters";
const THEME_KEY = "countly-theme";
const HUNT_KEY = "countly-yellow-hunt";
const starterCounters = [
  { id: crypto.randomUUID(), name: "Water glasses", count: 4 },
  { id: crypto.randomUUID(), name: "Daily steps", count: 1250 },
  { id: crypto.randomUUID(), name: "Books read", count: 2 },
];

let counters;
try { counters = JSON.parse(localStorage.getItem(STORAGE_KEY)) || starterCounters; } catch { counters = starterCounters; }

const grid = document.querySelector("#counter-grid");
const total = document.querySelector("#total-count");
const active = document.querySelector("#counter-count");
const themeToggle = document.querySelector("#theme-toggle");
const huntToggle = document.querySelector("#hunt-toggle");
const vehicleLayer = document.querySelector("#vehicle-layer");
const eyebrow = document.querySelector("#eyebrow");
const heroTitle = document.querySelector("#hero-title");
const appHint = document.querySelector("#app-hint");
const huntGuide = document.querySelector("#hunt-guide");
let huntMode = localStorage.getItem(HUNT_KEY) === "true";

function applyTheme(theme) {
  const dark = theme === "dark";
  document.body.classList.toggle("dark-mode", dark);
  themeToggle.title = dark ? "Switch to light mode" : "Switch to dark mode";
  themeToggle.setAttribute("aria-label", dark ? "Switch to light mode" : "Switch to dark mode");
}

function applyHuntMode() {
  document.body.classList.toggle("yellow-hunt", huntMode);
  huntGuide.hidden = !huntMode;
  huntToggle.classList.toggle("is-active", huntMode);
  huntToggle.title = huntMode ? "Exit Yellow Hunt mode" : "Activate Yellow Hunt mode";
  huntToggle.setAttribute("aria-label", huntMode ? "Exit Yellow Hunt mode" : "Activate Yellow Hunt mode");
  eyebrow.textContent = huntMode ? "Yellow Hunt" : "Your counters";
  heroTitle.textContent = huntMode ? "Spot it. Count it. Win it." : "Keep track of what matters.";
  appHint.innerHTML = huntMode
    ? '<span class="hint-key">PLAY</span> Log a yellow car or motorcycle when you spot one'
    : '<span class="hint-key">TIP</span> Click a counter’s name to rename it';
}

function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(counters)); }
function formatCount(value) { return new Intl.NumberFormat("en-US").format(value); }

function render() {
  grid.innerHTML = "";
  if (!counters.length) {
    grid.innerHTML = '<div class="empty-state"><strong>Your counter space is ready.</strong>Add a counter to get started.</div>';
  }
  counters.forEach((counter) => {
    const card = document.createElement("article");
    card.className = "counter-card";
    card.innerHTML = `
      <div class="card-top">
        <input class="counter-name" value="${escapeHtml(counter.name)}" aria-label="Counter name" maxlength="32" />
        <button class="delete-button" type="button" title="Remove counter" aria-label="Remove ${escapeHtml(counter.name)}">×</button>
      </div>
      <div class="count-controls">
        <button class="step-button increment" type="button" aria-label="Increase ${escapeHtml(counter.name)}">+</button>
        <div class="count">${formatCount(counter.count)}</div>
        <button class="step-button decrement" type="button" aria-label="Decrease ${escapeHtml(counter.name)}">−</button>
      </div>
      ${huntMode ? `<div class="hunt-actions">
        <button class="hunt-action car-action" type="button" aria-label="Log a yellow car for ${escapeHtml(counter.name)}"><span class="hunt-emoji">🚕</span><span>Car <b>+1</b></span></button>
        <button class="hunt-action moto-action" type="button" aria-label="Log a yellow motorcycle for ${escapeHtml(counter.name)}"><span class="hunt-emoji">🏍️</span><span>Motorcycle <b>+0.5</b></span></button>
      </div>` : '<p class="card-caption">Tap to adjust</p>'}`;
    card.querySelector(".increment").addEventListener("click", () => {
      updateCount(counter.id, 1);
      if (huntMode) showVehicle("car");
    });
    card.querySelector(".decrement").addEventListener("click", () => updateCount(counter.id, -1));
    card.querySelector(".car-action")?.addEventListener("click", () => { updateCount(counter.id, 1); showVehicle("car"); });
    card.querySelector(".moto-action")?.addEventListener("click", () => { updateCount(counter.id, .5); showVehicle("motorcycle"); });
    card.querySelector(".delete-button").addEventListener("click", () => removeCounter(counter.id));
    card.querySelector(".counter-name").addEventListener("change", (event) => {
      counter.name = event.target.value.trim() || "Untitled counter";
      save(); render();
    });
    grid.appendChild(card);
  });
  total.textContent = formatCount(counters.reduce((sum, item) => sum + item.count, 0));
  active.textContent = counters.length;
}

function updateCount(id, amount) { const counter = counters.find((item) => item.id === id); if (counter) { counter.count = Math.max(0, counter.count + amount); save(); render(); } }
function removeCounter(id) { counters = counters.filter((counter) => counter.id !== id); save(); render(); }
function escapeHtml(value) { return value.replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char])); }
function showVehicle(type) {
  const vehicle = document.createElement("div");
  vehicle.className = `passing-vehicle ${type} path-${Math.ceil(Math.random() * 3)}`;
  const startY = Math.round(14 + Math.random() * 64);
  const gentleShift = () => Math.round(-15 + Math.random() * 30);
  const midY = Math.max(10, Math.min(86, startY + gentleShift()));
  const endY = Math.max(10, Math.min(86, midY + gentleShift()));
  vehicle.style.setProperty("--start-y", `${startY}vh`);
  vehicle.style.setProperty("--mid-y", `${midY}vh`);
  vehicle.style.setProperty("--end-y", `${endY}vh`);
  vehicle.style.setProperty("--travel-time", `${(3.5 + Math.random() * 1.2).toFixed(2)}s`);
  vehicle.textContent = type === "car" ? "🚕" : "🏍️";
  vehicleLayer.appendChild(vehicle);
  vehicle.addEventListener("animationend", () => vehicle.remove());
}

document.querySelector("#add-counter").addEventListener("click", () => {
  counters.push({ id: crypto.randomUUID(), name: `Counter ${counters.length + 1}`, count: 0 });
  save(); render();
  setTimeout(() => grid.lastElementChild?.querySelector(".counter-name")?.select(), 0);
});
document.querySelector("#reset-all").addEventListener("click", () => { if (counters.length && confirm("Reset all counters to zero?")) { counters.forEach((counter) => { counter.count = 0; }); save(); render(); } });
huntToggle.addEventListener("click", () => { huntMode = !huntMode; localStorage.setItem(HUNT_KEY, huntMode); applyHuntMode(); render(); });
themeToggle.addEventListener("click", () => {
  const nextTheme = document.body.classList.contains("dark-mode") ? "light" : "dark";
  localStorage.setItem(THEME_KEY, nextTheme);
  applyTheme(nextTheme);
});
applyTheme(localStorage.getItem(THEME_KEY) || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
applyHuntMode();
render();
requestAnimationFrame(() => document.body.classList.add("app-ready"));
