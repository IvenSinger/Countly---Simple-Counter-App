const STORAGE_KEY = "countly-counters";
const THEME_KEY = "countly-theme";
const HUNT_KEY = "countly-yellow-hunt";
const TUTORIAL_KEY = "countly-tutorial-seen";
const starterCounters = [
  { id: crypto.randomUUID(), name: "Water glasses", count: 4 },
  { id: crypto.randomUUID(), name: "Daily steps", count: 1250 },
  { id: crypto.randomUUID(), name: "Books read", count: 2 },
];

let counters;
try { counters = JSON.parse(localStorage.getItem(STORAGE_KEY)) || starterCounters; } catch { counters = starterCounters; }

const grid = document.querySelector("#counter-grid");
const total = document.querySelector("#total-count");
const active = document.querySelector("#counter-count");
const themeToggle = document.querySelector("#theme-toggle");
const huntToggle = document.querySelector("#hunt-toggle");
const vehicleLayer = document.querySelector("#vehicle-layer");
const eyebrow = document.querySelector("#eyebrow");
const heroTitle = document.querySelector("#hero-title");
const appHint = document.querySelector("#app-hint");
const huntGuide = document.querySelector("#hunt-guide");
const tutorialOverlay = document.querySelector("#tutorial-overlay");
const tutorialSpotlight = document.querySelector("#tutorial-spotlight");
const tutorialArrow = document.querySelector("#tutorial-arrow");
const tutorialCard = document.querySelector("#tutorial-card");
const tutorialStep = document.querySelector("#tutorial-step");
const tutorialTitle = document.querySelector("#tutorial-title");
const tutorialCopy = document.querySelector("#tutorial-copy");
const continueTutorial = document.querySelector("#continue-tutorial");
const redoTutorial = document.querySelector("#redo-tutorial");
let tutorialIndex = 0;
const tutorialSteps = [
  { target: "#add-counter", title: "Make it yours", copy: "Add as many counters as you need, then give each one a name so everything stays easy to find." },
  { target: ".counter-card .increment", title: "Count in a tap", copy: "Use the plus and minus controls on any card to keep your numbers moving. Your progress is saved automatically." },
  { target: "#hunt-toggle", title: "Try Yellow Hunt", copy: "Switch on Yellow Hunt for the road game: log yellow cars for 1 point and yellow motorcycles for half a point." },
  { target: "#theme-toggle", title: "Set the mood", copy: "Toggle between light and dark mode whenever you like. Countly remembers your preference." },
];
let huntMode = localStorage.getItem(HUNT_KEY) === "true";

function applyTheme(theme) {
  const dark = theme === "dark";
  document.body.classList.toggle("dark-mode", dark);
  themeToggle.title = dark ? "Switch to light mode" : "Switch to dark mode";
  themeToggle.setAttribute("aria-label", dark ? "Switch to light mode" : "Switch to dark mode");
}

function applyHuntMode() {
  document.body.classList.toggle("yellow-hunt", huntMode);
  huntGuide.hidden = !huntMode;
  huntToggle.classList.toggle("is-active", huntMode);
  huntToggle.title = huntMode ? "Exit Yellow Hunt mode" : "Activate Yellow Hunt mode";
  huntToggle.setAttribute("aria-label", huntMode ? "Exit Yellow Hunt mode" : "Activate Yellow Hunt mode");
  eyebrow.textContent = huntMode ? "Yellow Hunt" : "Your counters";
  heroTitle.textContent = huntMode ? "Spot it. Count it. Win it." : "Keep track of what matters.";
  appHint.innerHTML = huntMode
    ? '<span class="hint-key">PLAY</span> Log a yellow car or motorcycle when you spot one'
    : '<span class="hint-key">TIP</span> Click a counter’s name to rename it';
}

function save() { localStorage.setItem(STORAGE_KEY, JSON.stringify(counters)); }
function formatCount(value) { return new Intl.NumberFormat("en-US").format(value); }

function render() {
  grid.innerHTML = "";
  if (!counters.length) {
    grid.innerHTML = '<div class="empty-state"><strong>Your counter space is ready.</strong>Add a counter to get started.</div>';
  }
  counters.forEach((counter) => {
    const card = document.createElement("article");
    card.className = "counter-card";
    card.innerHTML = `
      <div class="card-top">
        <input class="counter-name" value="${escapeHtml(counter.name)}" aria-label="Counter name" maxlength="32" />
        <button class="delete-button" type="button" title="Remove counter" aria-label="Remove ${escapeHtml(counter.name)}">×</button>
      </div>
      <div class="count-controls">
        <button class="step-button increment" type="button" aria-label="Increase ${escapeHtml(counter.name)}">+</button>
        <div class="count">${formatCount(counter.count)}</div>
        <button class="step-button decrement" type="button" aria-label="Decrease ${escapeHtml(counter.name)}">−</button>
      </div>
      ${huntMode ? `<div class="hunt-actions">
        <button class="hunt-action car-action" type="button" aria-label="Log a yellow car for ${escapeHtml(counter.name)}"><span class="hunt-emoji">🚕</span><span>Car <b>+1</b></span></button>
        <button class="hunt-action moto-action" type="button" aria-label="Log a yellow motorcycle for ${escapeHtml(counter.name)}"><span class="hunt-emoji">🏍️</span><span>Motorcycle <b>+0.5</b></span></button>
      </div>` : '<p class="card-caption">Tap to adjust</p>'}`;
    card.querySelector(".increment").addEventListener("click", () => {
      updateCount(counter.id, 1);
      if (huntMode) showVehicle("car");
    });
    card.querySelector(".decrement").addEventListener("click", () => updateCount(counter.id, -1));
    card.querySelector(".car-action")?.addEventListener("click", () => { updateCount(counter.id, 1); showVehicle("car"); });
    card.querySelector(".moto-action")?.addEventListener("click", () => { updateCount(counter.id, .5); showVehicle("motorcycle"); });
    card.querySelector(".delete-button").addEventListener("click", () => removeCounter(counter.id));
    card.querySelector(".counter-name").addEventListener("change", (event) => {
      counter.name = event.target.value.trim() || "Untitled counter";
      save(); render();
    });
    grid.appendChild(card);
  });
  total.textContent = formatCount(counters.reduce((sum, item) => sum + item.count, 0));
  active.textContent = counters.length;
}

function updateCount(id, amount) { const counter = counters.find((item) => item.id === id); if (counter) { counter.count = Math.max(0, counter.count + amount); save(); render(); } }
function removeCounter(id) { counters = counters.filter((counter) => counter.id !== id); save(); render(); }
function escapeHtml(value) { return value.replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char])); }
function showVehicle(type) {
  const vehicle = document.createElement("div");
  vehicle.className = `passing-vehicle ${type} path-${Math.ceil(Math.random() * 3)}`;
  const startY = Math.round(14 + Math.random() * 64);
  const gentleShift = () => Math.round(-15 + Math.random() * 30);
  const midY = Math.max(10, Math.min(86, startY + gentleShift()));
  const endY = Math.max(10, Math.min(86, midY + gentleShift()));
  vehicle.style.setProperty("--start-y", `${startY}vh`);
  vehicle.style.setProperty("--mid-y", `${midY}vh`);
  vehicle.style.setProperty("--end-y", `${endY}vh`);
  vehicle.style.setProperty("--travel-time", `${(3.5 + Math.random() * 1.2).toFixed(2)}s`);
  vehicle.textContent = type === "car" ? "🚕" : "🏍️";
  vehicleLayer.appendChild(vehicle);
  vehicle.addEventListener("animationend", () => vehicle.remove());
}

function positionTutorial() {
  const step = tutorialSteps[tutorialIndex];
  const target = document.querySelector(step.target);
  if (!target) return;
  const targetRect = target.getBoundingClientRect();
  const cardRect = tutorialCard.getBoundingClientRect();
  const gap = 24;
  const cardLeft = Math.max(16, Math.min(window.innerWidth - cardRect.width - 16, targetRect.left + targetRect.width / 2 - cardRect.width / 2));
  const below = targetRect.top < window.innerHeight / 2;
  const cardTop = Math.max(16, Math.min(window.innerHeight - cardRect.height - 16, below ? targetRect.bottom + gap : targetRect.top - cardRect.height - gap));
  tutorialCard.style.left = `${cardLeft}px`;
  tutorialCard.style.top = `${cardTop}px`;
  tutorialSpotlight.style.left = `${targetRect.left - 8}px`;
  tutorialSpotlight.style.top = `${targetRect.top - 8}px`;
  tutorialSpotlight.style.width = `${targetRect.width + 16}px`;
  tutorialSpotlight.style.height = `${targetRect.height + 16}px`;
  const startX = cardLeft + cardRect.width / 2;
  const startY = below ? cardTop : cardTop + cardRect.height;
  const endX = targetRect.left + targetRect.width / 2;
  const endY = below ? targetRect.bottom + 3 : targetRect.top - 3;
  const distance = Math.hypot(endX - startX, endY - startY);
  const angle = Math.atan2(endY - startY, endX - startX) * (180 / Math.PI);
  tutorialArrow.style.left = `${startX}px`;
  tutorialArrow.style.top = `${startY}px`;
  tutorialArrow.style.width = `${Math.max(20, distance)}px`;
  tutorialArrow.style.transform = `rotate(${angle}deg)`;
}

function showTutorialStep() {
  const step = tutorialSteps[tutorialIndex];
  tutorialStep.textContent = `${tutorialIndex + 1} / ${tutorialSteps.length}`;
  tutorialTitle.textContent = step.title;
  tutorialCopy.textContent = step.copy;
  continueTutorial.innerHTML = tutorialIndex === tutorialSteps.length - 1 ? 'Finish <span aria-hidden="true">✓</span>' : 'Continue <span aria-hidden="true">→</span>';
  tutorialOverlay.hidden = false;
  requestAnimationFrame(positionTutorial);
}

function launchConfetti() {
  const colors = ["#4169e1", "#ffd24d", "#ff9d72", "#8ed1c4", "#b79aff"];
  const release = (side) => {
    for (let index = 0; index < 32; index += 1) {
      const piece = document.createElement("span");
      piece.className = `confetti-piece confetti-${side}`;
      piece.style.left = side === "left" ? `${Math.random() * 10}vw` : `${90 + Math.random() * 10}vw`;
      piece.style.top = `${86 + Math.random() * 14}vh`;
      piece.style.background = colors[index % colors.length];
      piece.style.animationDelay = `${(Math.random() * .22).toFixed(2)}s`;
      piece.style.animationDuration = `${(1.6 + Math.random() * 1.3).toFixed(2)}s`;
      const drift = Math.round(90 + Math.random() * 230) * (side === "left" ? 1 : -1);
      piece.style.setProperty("--drift", `${drift}px`);
      piece.style.setProperty("--mid-drift", `${Math.round(drift * .45)}px`);
      piece.style.setProperty("--spin", `${Math.round(240 + Math.random() * 600)}deg`);
      document.body.appendChild(piece);
      piece.addEventListener("animationend", () => piece.remove());
    }
  };
  release("left");
  setTimeout(() => release("right"), 360);
}

function closeTutorial(completed = false) {
  tutorialOverlay.hidden = true;
  localStorage.setItem(TUTORIAL_KEY, "true");
  if (completed) launchConfetti();
}

document.querySelector("#add-counter").addEventListener("click", () => {
  counters.push({ id: crypto.randomUUID(), name: `Counter ${counters.length + 1}`, count: 0 });
  save(); render();
  setTimeout(() => grid.lastElementChild?.querySelector(".counter-name")?.select(), 0);
});
document.querySelector("#reset-all").addEventListener("click", () => { if (counters.length && confirm("Reset all counters to zero?")) { counters.forEach((counter) => { counter.count = 0; }); save(); render(); } });
huntToggle.addEventListener("click", () => { huntMode = !huntMode; localStorage.setItem(HUNT_KEY, huntMode); applyHuntMode(); render(); });
themeToggle.addEventListener("click", () => {
  const nextTheme = document.body.classList.contains("dark-mode") ? "light" : "dark";
  localStorage.setItem(THEME_KEY, nextTheme);
  applyTheme(nextTheme);
});
applyTheme(localStorage.getItem(THEME_KEY) || (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
applyHuntMode();
render();
requestAnimationFrame(() => {
  document.body.classList.add("app-ready");
  if (!localStorage.getItem(TUTORIAL_KEY)) showTutorialStep();
});

document.querySelector("#continue-tutorial").addEventListener("click", () => {
  if (tutorialIndex === tutorialSteps.length - 1) closeTutorial(true);
  else { tutorialIndex += 1; showTutorialStep(); }
});
document.querySelector("#skip-tutorial").addEventListener("click", closeTutorial);
redoTutorial.addEventListener("click", () => {
  tutorialIndex = 0;
  showTutorialStep();
});
window.addEventListener("resize", () => { if (!tutorialOverlay.hidden) positionTutorial(); });
window.addEventListener("scroll", () => { if (!tutorialOverlay.hidden) positionTutorial(); }, { passive: true });
